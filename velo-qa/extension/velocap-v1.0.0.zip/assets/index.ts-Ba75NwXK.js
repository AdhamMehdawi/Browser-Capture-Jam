import{M as b}from"./types-pU4PJcr7.js";const y="velocap/hook",k=500,C=300,x=500,d=[],h=new Map,c=[],a=[];console.info("%c[VeloCap] content script ready","color:#ff4d7e;font-weight:bold");window.addEventListener("message",o=>{if(o.source!==window)return;const e=o.data;if(!(!e||e.tag!==y)){if(console.debug("[velocap/content] received hook event",e.kind,e.payload),e.kind==="console"||e.kind==="error"||e.kind==="unhandledrejection"){const t=e.payload;d.push(t),d.length>k&&d.shift()}else if(e.kind==="network-start"){const t=e.payload;h.set(t.id,t)}else if(e.kind==="network-end"){const t=e.payload,n=h.get(t.id);if(!n)return;h.delete(t.id),c.push({...n,...t}),c.length>C&&c.shift()}else if(e.kind==="action"){const t=e.payload;if(t.type==="navigation"){const n=a[a.length-1];if(n&&n.type==="navigation"&&n.url===t.url)return}a.push(t),a.length>x&&a.shift()}}});function M(){var t;const o=window.devicePixelRatio||1,e=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";return{userAgent:navigator.userAgent,platform:((t=navigator.userAgentData)==null?void 0:t.platform)??navigator.platform,language:navigator.language,languages:Array.from(navigator.languages??[]),timezone:Intl.DateTimeFormat().resolvedOptions().timeZone,screen:{width:window.screen.width,height:window.screen.height,dpr:o,colorDepth:window.screen.colorDepth},viewport:{width:window.innerWidth,height:window.innerHeight},colorScheme:e}}function A(){return console.log("[velocap/content] collectPayload called",{consoleCount:d.length,networkCount:c.length,actionsCount:a.length}),{console:d.slice(),network:c.slice(),actions:a.slice(),device:M(),page:{url:window.location.href,title:document.title,referrer:document.referrer||void 0}}}let i=null,u=null,l=null,g=0,f=null;function S(o){const e=Math.max(0,Math.floor(o/1e3)),t=Math.floor(e/60),n=e%60;return`${t}:${String(n).padStart(2,"0")}`}function w(o){if(i)return;g=o||Date.now(),i=document.createElement("div"),i.setAttribute("data-velocap-overlay",""),i.style.cssText="all: initial; position: fixed; top: 12px; left: 50%; transform: translateX(-50%); z-index: 2147483647; pointer-events: auto;";const e=i.attachShadow({mode:"open"});e.innerHTML=`
    <style>
      :host { all: initial; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
      .bar {
        display: inline-flex; align-items: center; gap: 10px;
        padding: 8px 14px;
        background: #ffffff; color: #1a1a2e;
        border: 1px solid #e5e7eb; border-radius: 999px;
        font: 13px/1.3 -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        box-shadow: 0 4px 16px rgba(0,0,0,0.10), 0 1px 3px rgba(0,0,0,0.06);
        user-select: none;
      }
      .logo { height: 18px; width: auto; flex-shrink: 0; }
      .dot {
        width: 8px; height: 8px; border-radius: 50%;
        background: #ef4444;
        animation: pulse 1s infinite ease-in-out;
      }
      .timer { font-variant-numeric: tabular-nums; color: #6b7280; min-width: 34px; text-align: center; font-weight: 500; }
      button {
        background: #7c3aed; color: #ffffff; border: 0; border-radius: 6px;
        padding: 6px 14px; font: inherit; font-weight: 600; cursor: pointer;
        transition: background 0.15s;
      }
      button:disabled { background: #e5e7eb; color: #9ca3af; cursor: default; }
      button:hover:not(:disabled) { background: #6d28d9; }
      @keyframes pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50%      { opacity: 0.4; transform: scale(1.5); }
      }
    </style>
    <div class="bar" role="status" aria-live="polite">
      <svg class="logo" xmlns="http://www.w3.org/2000/svg" viewBox="350 90 300 250"><path fill="#7c3aed" d="M546.778381,143.170624C571.837769,159.376846 596.645569,175.305298 621.322937,191.433304C636.009155,201.031509 635.978516,216.712524 621.371460,226.194397C576.110229,255.574753 530.847717,284.953583 485.503937,314.206238C472.276642,322.739563 459.865479,318.754028 453.794159,304.396240C425.790985,238.172882 397.800232,171.944290 369.830170,105.706955C369.077332,103.924194 367.954132,102.184967 368.359497,99.792320C371.491486,98.422760 374.856354,99.127960 378.098694,99.068153C385.426880,98.932976 392.763336,99.161888 400.087982,98.950737C403.767334,98.844666 405.815216,100.090027 407.237396,103.618439C417.878113,130.018570 428.701080,156.345245 439.462555,182.696701C444.289581,194.516510 449.106537,206.340408 454.767395,218.077042C454.767395,210.186707 454.769012,202.296356 454.767090,194.406006C454.761017,169.581909 454.815948,144.757568 454.710480,119.933884C454.677002,112.059120 456.822998,105.459862 464.040466,101.364922C471.543579,97.107903 478.433380,99.167374 485.133606,103.492462C505.562927,116.679909 526.023499,129.818924 546.778381,143.170624M487.077606,177.500229C487.088318,196.659058 487.097656,215.817871 487.110474,234.976700C487.115601,242.640198 486.990417,250.307053 487.176819,257.966248C487.361481,265.554352 493.136444,268.822632 499.920197,265.331207C501.841492,264.342316 503.688873,263.195923 505.509277,262.026917C523.025391,250.778488 540.529297,239.510925 558.034729,228.245773C561.167725,226.229553 564.291687,224.199097 568.479797,221.489456C565.252991,238.021347 557.077332,250.810303 549.042114,263.705475C555.025513,258.754944 560.207947,253.170654 564.589417,246.857254C574.476318,232.610870 581.915833,217.562714 579.724915,199.476318C578.750366,191.431412 575.671753,184.236603 570.779297,177.840118C572.674500,186.055344 575.610046,194.033020 574.522217,203.760239C570.794800,199.851517 568.074524,196.773041 564.520142,194.506149C556.095520,189.133087 547.900330,183.401398 539.506714,177.978363C526.497131,169.573074 513.505432,161.131058 500.296631,153.047012C493.184265,148.694077 487.352753,152.185699 487.141632,160.507706C487.006470,165.835632 487.099609,171.169327 487.077606,177.500229z"/><path fill="#ef4444" d="M516.001099,189.525391C527.921936,187.016037 537.708862,192.994354 540.377869,204.043137C543.029785,215.020767 537.080444,225.186371 526.369263,227.979706C515.840759,230.725403 505.525635,224.949127 502.393585,214.553787C499.126343,203.709702 504.189117,194.169617 516.001099,189.525391z"/></svg>
      <span class="dot" aria-hidden="true"></span>
      <span class="timer" id="oj-timer">0:00</span>
      <button id="oj-stop">Stop</button>
    </div>
  `,(document.documentElement||document.body).appendChild(i),u=e.getElementById("oj-timer"),l=e.getElementById("oj-stop"),l.addEventListener("click",()=>{l&&(l.disabled=!0,l.textContent="Stopping…",chrome.runtime.sendMessage({kind:"bg:record-stop"}))});const t=()=>{u&&(u.textContent=S(Date.now()-g))};t(),f=window.setInterval(t,500)}function m(){f!=null&&(window.clearInterval(f),f=null),i&&(i.remove(),i=null,u=null,l=null)}let r=null,s=null;function v(){s&&(window.removeEventListener("message",s),s=null),r&&(r.remove(),r=null)}function E(o){v(),m();const e=chrome.runtime.getURL("src/preview/index.html")+"?embed=1";r=document.createElement("div"),r.setAttribute("data-velocap-preview",""),r.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647;";const t=r.attachShadow({mode:"open"});t.innerHTML=`
    <style>
      :host { all: initial; }
      .backdrop {
        position: fixed; inset: 0;
        background: rgba(0,0,0,.72);
        backdrop-filter: blur(6px);
        display: flex; align-items: center; justify-content: center;
        padding: 24px;
        animation: fade .15s ease-out;
      }
      .frame {
        width: min(960px, 100%);
        height: min(720px, 85vh);
        border: 1px solid #22283a;
        border-radius: 14px;
        overflow: hidden;
        background: #0b0d12;
        box-shadow: 0 24px 80px rgba(0,0,0,.6);
      }
      iframe { width: 100%; height: 100%; border: 0; display: block; background: #0b0d12; }
      @keyframes fade { from { opacity: 0 } to { opacity: 1 } }
    </style>
    <div class="backdrop">
      <div class="frame">
        <iframe
          src="${e}"
          allow="autoplay; clipboard-write"
          title="VeloCap preview"
        ></iframe>
      </div>
    </div>
  `,(document.documentElement||document.body).appendChild(r),s=n=>{const p=n.data;!p||p.tag!=="velocap/preview"||p.action==="close"&&v()},window.addEventListener("message",s)}chrome.runtime.onMessage.addListener((o,e,t)=>{if((o==null?void 0:o.kind)===b.capture)return t(A()),!0;if((o==null?void 0:o.kind)==="overlay:show")return w(o.startedAt),t({ok:!0}),!1;if((o==null?void 0:o.kind)==="overlay:hide")return m(),t({ok:!0}),!1;if((o==null?void 0:o.kind)==="preview:show")return E(),t({ok:!0}),!1;if((o==null?void 0:o.kind)==="preview:hide")return v(),t({ok:!0}),!1});(function(){try{chrome.runtime.sendMessage({kind:"bg:state"}).then(e=>{(e==null?void 0:e.state)==="recording"&&typeof e.startedAt=="number"&&w(e.startedAt)}).catch(()=>{setTimeout(()=>{chrome.runtime.sendMessage({kind:"bg:state"}).then(e=>{(e==null?void 0:e.state)==="recording"&&typeof e.startedAt=="number"&&w(e.startedAt)}).catch(()=>{})},400)})}catch{}})();

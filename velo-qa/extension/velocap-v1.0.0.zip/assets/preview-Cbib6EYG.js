import"./modulepreload-polyfill-B5Qt9EMX.js";import{_ as X}from"./preload-helper-D7HrI6pR.js";const K=document.getElementById("main"),C=document.getElementById("meta"),ee=document.getElementById("close-header");ee.addEventListener("click",async()=>{await chrome.runtime.sendMessage({kind:"bg:preview-discard"}),window.close()});function _(i){const r=Math.max(0,Math.round(i/1e3));return`${Math.floor(r/60)}:${String(r%60).padStart(2,"0")}`}function Y(i){return i>1024*1024?`${(i/1024/1024).toFixed(1)} MB`:i>1024?`${(i/1024).toFixed(0)} KB`:`${i} B`}function te(i){K.innerHTML=`<div class="empty">${i}</div>`}function ne(i){const r=()=>{if(i.duration===1/0||Number.isNaN(i.duration)){const v=()=>{i.removeEventListener("seeked",v),i.currentTime=0};i.addEventListener("seeked",v),i.currentTime=1e101}};i.readyState>=1?r():i.addEventListener("loadedmetadata",r,{once:!0})}function oe(i){C.textContent=`${_(i.durationMs)} · ${Y(i.bytes)}`,console.log("[velocap/preview] rendering",{bytes:i.bytes,durationMs:i.durationMs,readSasUrl:i.readSasUrl?"(present)":"(missing)",mime:i.mimeType});const r=i.durationMs||1;let v=0,d=r;if(K.innerHTML=`
    <div class="player-wrap" id="player-wrap">
      <video id="video" controls autoplay playsinline></video>
    </div>
    <div class="trim-info" id="trim-info">
      <span class="trim-badge" id="trim-badge">✂ Full video</span>
    </div>
    <div class="card">
      <div>
        <label for="title">Title (optional)</label>
        <input id="title" type="text" placeholder="e.g. Login button broken on Safari" />
      </div>
      <div class="row right">
        <button id="discard" class="danger">Discard</button>
        <button id="download">Download</button>
        <button id="upload" class="primary">Upload</button>
      </div>
      <div class="status" id="status"></div>
    </div>
  `,!document.getElementById("trim-styles")){const a=document.createElement("style");a.id="trim-styles",a.textContent=`
      .player-wrap { position: relative; border-radius: 10px; overflow: visible; }
      .trim-info {
        display: flex; align-items: center; justify-content: center;
        padding: 6px 0; min-height: 24px;
      }
      .trim-badge {
        font-size: 11px; color: var(--muted); font-family: ui-monospace, monospace;
        background: var(--surface); border: 1px solid var(--border);
        padding: 2px 10px; border-radius: 20px;
      }
      .trim-badge.active { color: var(--accent); border-color: var(--accent); background: rgba(124,58,237,0.08); }

      /* Trim overlay on the Plyr progress bar */
      .plyr__progress { position: relative !important; }
      .trim-overlay {
        position: absolute; top: -8px; left: 0; right: 0; bottom: -8px;
        pointer-events: none; z-index: 10;
      }
      .trim-overlay-left, .trim-overlay-right {
        position: absolute; top: 0; bottom: 0;
        background: rgba(0,0,0,0.45); pointer-events: none;
        transition: width 0.05s ease;
      }
      .trim-overlay-left { left: 0; border-radius: 4px 0 0 4px; }
      .trim-overlay-right { right: 0; border-radius: 0 4px 4px 0; }

      .trim-handle {
        position: absolute; top: -4px; bottom: -4px; width: 10px;
        background: var(--accent); border-radius: 3px; cursor: col-resize;
        pointer-events: auto; z-index: 11;
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 0 4px rgba(124,58,237,0.4);
        transition: background 0.15s;
      }
      .trim-handle:hover, .trim-handle.dragging { background: var(--accent-hover); }
      .trim-handle::after {
        content: ''; width: 2px; height: 10px;
        background: rgba(255,255,255,0.7); border-radius: 1px;
      }
      .trim-handle-start { transform: translateX(-50%); }
      .trim-handle-end { transform: translateX(50%); }

      .trim-time-tooltip {
        position: absolute; top: -26px; left: 50%; transform: translateX(-50%);
        background: var(--fg); color: var(--bg); font-size: 10px;
        font-family: ui-monospace, monospace; padding: 2px 6px;
        border-radius: 4px; white-space: nowrap; pointer-events: none;
        opacity: 0; transition: opacity 0.15s;
      }
      .trim-handle.dragging .trim-time-tooltip,
      .trim-handle:hover .trim-time-tooltip { opacity: 1; }
    `,document.head.appendChild(a)}const l=document.getElementById("video");ne(l);const P=document.getElementById("trim-badge");(async()=>{try{const{default:a}=await X(async()=>{const{default:m}=await import("./plyr-D2GZHiRV.js");return{default:m}},[]),o=await X(()=>import("./plyr-CsVBR1bC.js"),[]),s=document.createElement("style");s.textContent=o.default,document.head.appendChild(s);const u=Math.max(1,Math.round(i.durationMs/1e3));new a(l,{controls:["play","progress","current-time","mute","volume","fullscreen"],duration:u}),await new Promise(m=>setTimeout(m,200));const b=document.querySelector(".plyr__progress");b&&J(b)}catch{}})();function J(a){const o=document.createElement("div");o.className="trim-overlay";const s=document.createElement("div");s.className="trim-overlay-left";const u=document.createElement("div");u.className="trim-overlay-right";const b=document.createElement("div");b.className="trim-handle trim-handle-start",b.innerHTML='<span class="trim-time-tooltip" id="tt-start">0:00</span>';const m=document.createElement("div");m.className="trim-handle trim-handle-end",m.innerHTML=`<span class="trim-time-tooltip" id="tt-end">${_(r)}</span>`,o.appendChild(s),o.appendChild(u),o.appendChild(b),o.appendChild(m),a.style.position="relative",a.appendChild(o);const j=document.getElementById("tt-start"),R=document.getElementById("tt-end");function O(){const c=v/r*100,f=d/r*100;s.style.width=`${c}%`,u.style.width=`${100-f}%`,b.style.left=`${c}%`,m.style.right=`${100-f}%`,j.textContent=_(v),R.textContent=_(d);const k=v===0&&d>=r-100;P.textContent=k?"✂ Full video":`✂ ${_(v)} – ${_(d)}`,P.classList.toggle("active",!k)}O();function y(c,f){let k=!1;c.addEventListener("mousedown",T=>{T.preventDefault(),T.stopPropagation(),k=!0,c.classList.add("dragging")}),document.addEventListener("mousemove",T=>{if(!k)return;const I=a.getBoundingClientRect(),$=Math.max(0,Math.min(1,(T.clientX-I.left)/I.width));f($),O()}),document.addEventListener("mouseup",()=>{k&&(k=!1,c.classList.remove("dragging"))})}y(b,c=>{v=Math.min(Math.round(c*r/100)*100,d-500),l.currentTime=v/1e3}),y(m,c=>{d=Math.max(Math.round(c*r/100)*100,v+500),l.currentTime=d/1e3})}(async()=>{try{const{loadBlob:a}=await X(async()=>{const{loadBlob:s}=await import("./indexeddb-Bj0kk763.js");return{loadBlob:s}},[]),o=await a("pending-recording");if(o){const s=URL.createObjectURL(o);l.src=s,l.load(),window.addEventListener("beforeunload",()=>URL.revokeObjectURL(s)),console.log("[velocap/preview] loaded from IndexedDB (instant)",o.size);return}}catch(a){console.warn("[velocap/preview] IndexedDB load failed, using Azure URL",a)}l.src=i.readSasUrl,l.load(),console.log("[velocap/preview] loaded from Azure SAS URL (fallback)")})(),l.addEventListener("timeupdate",()=>{l.currentTime<v/1e3-.1&&(l.currentTime=v/1e3),d<r&&l.currentTime>=d/1e3&&(l.pause(),l.currentTime=v/1e3)}),l.addEventListener("error",()=>{var a;console.error("[velocap/preview] video error",l.error),E(`Video playback failed (${((a=l.error)==null?void 0:a.message)??"unknown"}). Use Download to save the file.`,"err")});const B=document.getElementById("status"),E=(a,o="")=>{B.textContent=a,B.className="status"+(o?" "+o:"")},N=document.getElementById("title");let L=document.getElementById("discard"),t=document.getElementById("download"),h=document.getElementById("upload");const w=(a,o)=>{const s=a.cloneNode(!0);return a.replaceWith(s),s.addEventListener("click",o),s};L.addEventListener("click",async()=>{await chrome.runtime.sendMessage({kind:"bg:preview-discard"}),window.close()}),t.addEventListener("click",async()=>{E("Preparing download…");const a=await chrome.runtime.sendMessage({kind:"bg:download-preview"});if(a!=null&&a.ok)E("✓ Download started","ok");else try{const o=document.createElement("a");o.href=i.readSasUrl,o.download=`velocap-${Date.now()}.webm`,o.click(),E("✓ Download started (fallback)","ok")}catch(o){E(`Download failed: ${(a==null?void 0:a.message)??(o instanceof Error?o.message:String(o))}`,"err")}}),h.addEventListener("click",async()=>{h.disabled=!0,h.textContent="Uploading…",L.disabled=!0,t.disabled=!0;const a=v>0||d<r-100,o=await chrome.runtime.sendMessage({kind:"bg:preview-upload",title:N.value.trim()||void 0,...a?{trimStartMs:v,trimEndMs:d}:{}});if(o!=null&&o.ok){try{await navigator.clipboard.writeText(o.url)}catch{}N.readOnly=!0,N.classList.add("readonly");const s=N.value.trim();if(s){const b=C.textContent??"";C.textContent="";const m=document.createElement("strong");m.className="title",m.textContent=s,C.appendChild(m),b&&C.appendChild(document.createTextNode(" · "+b))}h.textContent="✓ Uploaded",h.disabled=!1,h.className="primary",setTimeout(()=>{h=w(h,()=>window.open(o.url,"_blank")),h.textContent="Open",h.className="primary"},1200),L=w(L,()=>window.close()),L.textContent="Close",L.className="ghost",L.disabled=!1,t.disabled=!1;const u=document.createElement("button");u.textContent="Copy Link",u.className="secondary",u.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(o.url),u.textContent="✓ Copied!",setTimeout(()=>{u.textContent="Copy Link"},2e3)}catch{E("Failed to copy","err")}}),t.insertAdjacentElement("afterend",u),E("✓ Uploaded & copied to clipboard!","ok")}else h.textContent="Upload",h.disabled=!1,L.disabled=!1,t.disabled=!1,E((o==null?void 0:o.message)||"Upload failed","err")})}async function ae(i){const r=await X(()=>import("./index.min-Cb8l04Eb.js"),[]),v=i.screenshotDataUrl||i.readSasUrl;C.textContent=Y(i.bytes),K.innerHTML=`
    <div class="annotation-toolbar" id="toolbar">
      <button id="tool-select" title="Select">🔲</button>
      <button id="tool-draw" title="Draw">✏️</button>
      <button id="tool-rect" title="Rectangle">▭</button>
      <button id="tool-circle" title="Circle">○</button>
      <button id="tool-arrow" title="Arrow">↗</button>
      <button id="tool-text" title="Text">T</button>
      <div class="separator"></div>
      <input type="color" id="tool-color" value="#ef4444" title="Color" />
      <div class="separator"></div>
      <button id="tool-undo" title="Undo">↩</button>
      <button id="tool-redo" title="Redo">↪</button>
      <button id="tool-clear" title="Clear all">🗑</button>
    </div>
    <div class="canvas-container" id="canvas-wrap">
      <canvas id="annotation-canvas"></canvas>
    </div>
    <div class="bottom-bar">
      <input id="title" type="text" placeholder="Title (optional)" />
      <button id="discard" class="ghost">Discard</button>
      <button id="download" class="secondary">Download</button>
      <button id="upload" class="primary">Upload</button>
    </div>
  `;const d=new Image;d.crossOrigin="anonymous",d.src=v,await new Promise(n=>{d.onload=()=>n()}),await new Promise(n=>requestAnimationFrame(n));const l=document.getElementById("canvas-wrap"),P=Math.min(920,l.clientWidth),J=l.clientHeight,B=Math.min(P/d.naturalWidth,J/d.naturalHeight,1),E=Math.round(d.naturalWidth*B),N=Math.round(d.naturalHeight*B),L=document.getElementById("annotation-canvas"),t=new r.Canvas(L,{width:E,height:N}),h=new r.FabricImage(d,{scaleX:B,scaleY:B,selectable:!1,evented:!1});t.backgroundImage=h,t.renderAll();let w="select",a="#ef4444";const o=[],s=[];function u(){o.push(JSON.stringify(t.toJSON())),s.length=0}u();const b={"tool-select":"select","tool-draw":"draw","tool-rect":"rect","tool-circle":"circle","tool-arrow":"arrow","tool-text":"text"};function m(){const n=w==="select";t.getObjects().forEach(e=>{e.selectable=n,e.evented=n}),t.requestRenderAll()}function j(n){w=n,t.isDrawingMode=n==="draw",t.selection=n==="select",n!=="select"&&t.discardActiveObject(),m(),Object.entries(b).forEach(([e,p])=>{var g;(g=document.getElementById(e))==null||g.classList.toggle("active",p===n)})}Object.entries(b).forEach(([n,e])=>{document.getElementById(n).addEventListener("click",()=>j(e))});const R=document.getElementById("tool-color");R.addEventListener("input",()=>{a=R.value,t.freeDrawingBrush&&(t.freeDrawingBrush.color=a)}),t.freeDrawingBrush=new r.PencilBrush(t),t.freeDrawingBrush.color=a,t.freeDrawingBrush.width=3;let O=!1,y=0,c=0,f=null;t.on("mouse:down",n=>{if(w==="text"){const p=t.getScenePoint(n.e),g=new r.IText("Type here",{left:p.x,top:p.y,fontSize:18/B,fill:a,fontFamily:"sans-serif"});t.add(g),t.setActiveObject(g),g.enterEditing(),u(),j("select");return}if(!["rect","circle","arrow"].includes(w))return;O=!0;const e=t.getScenePoint(n.e);y=e.x,c=e.y,w==="rect"?f=new r.Rect({left:y,top:c,width:0,height:0,fill:"transparent",stroke:a,strokeWidth:3}):w==="circle"?f=new r.Ellipse({left:y,top:c,rx:0,ry:0,fill:"transparent",stroke:a,strokeWidth:3}):w==="arrow"&&(f=new r.Line([y,c,y,c],{stroke:a,strokeWidth:3})),f&&(t.add(f),t.selection=!1)}),t.on("mouse:move",n=>{if(!O||!f)return;const e=t.getScenePoint(n.e);w==="rect"?f.set({width:Math.abs(e.x-y),height:Math.abs(e.y-c),left:Math.min(e.x,y),top:Math.min(e.y,c)}):w==="circle"?f.set({rx:Math.abs(e.x-y)/2,ry:Math.abs(e.y-c)/2,left:Math.min(e.x,y),top:Math.min(e.y,c)}):w==="arrow"&&f.set({x2:e.x,y2:e.y}),t.renderAll()}),t.on("mouse:up",n=>{if(O&&f){if(w==="arrow"){const e=f,p=e.x1,g=e.y1,M=e.x2,U=e.y2,z=Math.atan2(U-g,M-p),F=15,W=Math.PI/6,Z=new r.Polygon([{x:M,y:U},{x:M-F*Math.cos(z-W),y:U-F*Math.sin(z-W)},{x:M-F*Math.cos(z+W),y:U-F*Math.sin(z+W)}],{fill:a,stroke:a,strokeWidth:1,selectable:!1,evented:!1});t.add(Z)}u(),m(),f=null,O=!1}}),t.on("path:created",()=>{u(),m()}),document.getElementById("tool-undo").addEventListener("click",()=>{o.length<=1||(s.push(o.pop()),t.loadFromJSON(JSON.parse(o[o.length-1])).then(()=>{t.renderAll(),m(),S()}))}),document.getElementById("tool-redo").addEventListener("click",()=>{if(s.length===0)return;const n=s.pop();o.push(n),t.loadFromJSON(JSON.parse(n)).then(()=>{t.renderAll(),m(),S()})}),document.getElementById("tool-clear").addEventListener("click",()=>{t.getObjects().forEach(n=>t.remove(n)),t.renderAll(),u(),S()}),document.addEventListener("keydown",n=>{if(n.key!=="Delete"&&n.key!=="Backspace")return;const e=n.target,p=e==null?void 0:e.tagName;if(p==="INPUT"||p==="TEXTAREA"||p==="SELECT"||e!=null&&e.isContentEditable)return;const g=t.getActiveObject();if(!g||g.isEditing)return;const M=t.getActiveObjects();M.length!==0&&(t.discardActiveObject(),t.remove(...M),t.requestRenderAll(),u(),S(),n.preventDefault())});function k(){const n=document.createElement("canvas");n.width=d.naturalWidth,n.height=d.naturalHeight;const e=n.getContext("2d");e.drawImage(d,0,0);const p=t.toCanvasElement();return e.drawImage(p,0,0,E,N,0,0,d.naturalWidth,d.naturalHeight),n.toDataURL("image/png")}let T=!1,I;async function $(){if(!T)try{const n=k(),e=await(await fetch(n)).blob();if(T)return;C.textContent=Y(e.size)}catch{}}function S(){T||(I!==void 0&&window.clearTimeout(I),I=window.setTimeout(()=>{$()},300))}$(),t.on("object:added",S),t.on("object:modified",S),t.on("object:removed",S),t.on("path:created",S);const V=document.getElementById("status"),q=(n,e="")=>{V&&(V.textContent=n,V.className="status"+(e?" "+e:""))},H=document.getElementById("title");let D=document.getElementById("discard");const A=document.getElementById("download");let x=document.getElementById("upload");const G=(n,e)=>{const p=n.cloneNode(!0);return n.replaceWith(p),p.addEventListener("click",e),p};D.addEventListener("click",async()=>{await chrome.runtime.sendMessage({kind:"bg:preview-discard"}),window.close()}),A.addEventListener("click",()=>{const n=k(),e=document.createElement("a");e.href=n,e.download=`velocap-${Date.now()}.png`,e.click(),q("Download started","ok")}),x.addEventListener("click",async()=>{x.disabled=!0,x.textContent="Uploading…",D.disabled=!0,A.disabled=!0;const n=k(),e=await chrome.runtime.sendMessage({kind:"bg:preview-upload",title:H.value.trim()||void 0,annotatedDataUrl:n});if(e!=null&&e.ok){try{await navigator.clipboard.writeText(e.url)}catch{}T=!0,I!==void 0&&window.clearTimeout(I),H.readOnly=!0,H.classList.add("readonly");const p=H.value.trim();if(p){const M=C.textContent??"";C.textContent="";const U=document.createElement("strong");U.className="title",U.textContent=p,C.appendChild(U),M&&C.appendChild(document.createTextNode(" · "+M))}x.textContent="✓ Uploaded",x.disabled=!1,x.className="primary",setTimeout(()=>{x=G(x,()=>window.open(e.url,"_blank")),x.textContent="Open",x.className="primary"},1200),D=G(D,()=>window.close()),D.textContent="Close",D.className="ghost",D.disabled=!1,A.disabled=!1;const g=document.createElement("button");g.textContent="Copy Link",g.className="secondary",g.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(e.url),g.textContent="✓ Copied!",setTimeout(()=>{g.textContent="Copy Link"},2e3)}catch{q("Failed to copy","err")}}),A.insertAdjacentElement("afterend",g)}else x.textContent="Upload",x.disabled=!1,D.disabled=!1,A.disabled=!1,q((e==null?void 0:e.message)||"Upload failed","err")})}const Q=new URLSearchParams(location.search).get("embed")==="1";function ie(){Q?window.parent.postMessage({tag:"velocap/preview",action:"close"},"*"):window.close()}const re=window.close.bind(window);window.close=()=>{Q?ie():re()};(async()=>{const i=await chrome.runtime.sendMessage({kind:"bg:get-pending-preview"});if(!i||i.empty){te("Nothing to preview — the recording was already uploaded or discarded.");return}const r=i;r.mediaType==="screenshot"?await ae(r):oe(r)})();

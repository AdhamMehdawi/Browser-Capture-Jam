const t={capture:"capture-context"};export{t as M};
